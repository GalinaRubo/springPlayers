package util;

public class TbConstants {
    public static interface Roles {
        String USER = "USER";
        String ADMIN = "ADMIN";
    }
}
