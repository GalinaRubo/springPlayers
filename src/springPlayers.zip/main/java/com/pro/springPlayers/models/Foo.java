package com.pro.springPlayers.models;

import java.util.List;

public class Foo {
 private List<Long> checkedItems;
 
 public Foo() {}
	 

	 public List<Long> getCheckedItems() {
	        return checkedItems;
	    }

	    public void setCheckedItems(List<Long> checkedItems) {
	        this.checkedItems = checkedItems;
	    }
}
